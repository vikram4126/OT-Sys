import React, { useState, useEffect } from 'react';
import { C } from './theme';
import { Dashboard, Upload, Vuln, Mitigation, Compliance, Report, Bell, Search } from './components/Icons';
import DashboardTab       from './components/DashboardTab';
import ModelTab          from './components/ModelTab';
import VulnerabilitiesTab from './components/VulnerabilitiesTab';
import RiskLandscapeTab   from './components/RiskLandscapeTab';
import Compliance62443Tab from './components/Compliance62443Tab';
import AssetsTab from './components/AssetsTab';
import MitigationsTab     from './components/MitigationsTab';
import ReportTab          from './components/ReportTab';
import LogsTab            from './components/LogsTab';
import AdminPortal        from './components/AdminPortal';
import { seedDemoLogs, addLog, LOG_TYPES } from './services/logService';
import { hasBaseline, SNAPSHOT_EVENT } from './services/snapshotService';

const LogsIcon = () => (
  <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" style={{flexShrink:0}}>
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
    <line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>
  </svg>
);
const Network = () => (
  <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" style={{flexShrink:0}}>
    <rect x="2" y="2" width="6" height="6" rx="1"/><rect x="16" y="2" width="6" height="6" rx="1"/><rect x="9" y="16" width="6" height="6" rx="1"/>
    <path d="M5 8v4a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8"/><line x1="12" y1="12" x2="12" y2="16"/>
  </svg>
);
const GearLogo = () => (
  <svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke={C.navy} strokeWidth="1.6" strokeLinecap="round">
    <circle cx="12" cy="12" r="3"/>
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
  </svg>
);

// Nav — the assessment journey, end to end
const NAV = [
  { label:'Assessment', items:[
    { id:'dashboard',  label:'Dashboard',       Icon:Dashboard },
    { id:'model',      label:'Model',            Icon:Upload },
    { id:'assets',     label:'Assets',           Icon:Network },
    { id:'compliance', label:'IEC 62443',        Icon:Compliance },
  ]},
  { label:'Analysis', items:[
    { id:'vulns',      label:'Vulnerabilities',  Icon:Vuln, badge:4 },
    { id:'risk',       label:'Risk Landscape',   Icon:Network },
    { id:'mitigations',label:'Mitigations',      Icon:Mitigation },
  ]},
  { label:'Reports', items:[
    { id:'report',     label:'Report',           Icon:Report },
    { id:'logs',       label:'Audit Logs',       Icon:LogsIcon },
  ]},
];

const TITLES = {
  dashboard:'Dashboard', model:'Model',
  vulns:'Vulnerabilities', risk:'Risk Landscape', compliance:'IEC 62443',
  mitigations:'Mitigations', report:'Report', logs:'Audit Logs',
};

export default function App() {
  const [tab,       setTab]       = useState(hasBaseline() ? 'dashboard' : 'model');
  const [adminMode, setAdminMode] = useState(false);
  // Gate: analysis tabs stay locked until the consultant captures the initial
  // baseline (their declaration that the starting evidence is loaded).
  const [baselineDone, setBaselineDone] = useState(hasBaseline());

  useEffect(() => { seedDemoLogs(); addLog(LOG_TYPES.LOGIN, 'User session started'); }, []);
  useEffect(() => {
    const sync = () => setBaselineDone(hasBaseline());
    window.addEventListener(SNAPSHOT_EVENT, sync);
    return () => window.removeEventListener(SNAPSHOT_EVENT, sync);
  }, []);

  if (adminMode) return <AdminPortal onExit={() => setAdminMode(false)}/>;

  // Only setup is open before the baseline. Evidence is now collected in Model
  // (collect-flat), so 62443 is an analysis view that needs the baseline first.
  const PRE_BASELINE_OPEN = ['model'];
  const locked = (id) => !baselineDone && !PRE_BASELINE_OPEN.includes(id);

  return (
    <div style={{ display:'flex', height:'100vh', fontFamily:"'Segoe UI',-apple-system,sans-serif", background:'#F2F5FB', color:C.text, overflow:'hidden', fontSize:14 }}>

      {/* ── Sidebar ──────────────────────────────────────────────────────── */}
      <div style={{ width:228, background:'#fff', display:'flex', flexDirection:'column', flexShrink:0, borderRight:`1px solid ${C.border}`, boxShadow:'2px 0 8px rgba(0,0,0,.04)' }}>
        {/* Logo */}
        <div style={{ padding:'18px 16px 14px', display:'flex', alignItems:'center', gap:10, borderBottom:'1px solid #EEF2FA' }}>
          <div style={{ width:35, height:35, borderRadius:9, background:`${C.navy}0E`, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}><GearLogo/></div>
          <div>
            <div style={{ fontWeight:700, fontSize:14, color:C.navy, letterSpacing:-.3 }}>OT Overview</div>
            <div style={{ fontSize:10, color:C.muted, marginTop:1 }}>OT Security Platform</div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex:1, overflowY:'auto', padding:'8px 8px' }}>
          {NAV.map(sec => (
            <div key={sec.label} style={{ marginBottom:2 }}>
              <div style={{ fontSize:9, fontWeight:700, color:'#B0BCCE', letterSpacing:1.5, textTransform:'uppercase', padding:'8px 10px 4px' }}>{sec.label}</div>
              {sec.items.map(n => {
                const active = tab === n.id;
                const isLocked = locked(n.id);
                return (
                  <div key={n.id} onClick={() => { if (!isLocked) setTab(n.id); }}
                    title={isLocked ? 'Locked until the initial baseline is captured (Model tab)' : ''}
                    style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 10px', borderRadius:8, cursor:isLocked?'not-allowed':'pointer', marginBottom:1, background:active?`${C.navy}0E`:'transparent', color:isLocked?'#C0CADA':(active?C.navy:C.muted), fontWeight:active?600:400, fontSize:13, transition:'all .12s', borderLeft:active?`3px solid ${C.navy}`:'3px solid transparent' }}>
                    <n.Icon/>
                    <span style={{ flex:1 }}>{n.label}</span>
                    {isLocked
                      ? <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                      : (n.badge && <span style={{ background:C.navy, color:'#fff', borderRadius:10, fontSize:10, fontWeight:700, padding:'1px 7px', lineHeight:1.6 }}>{n.badge}</span>)}
                  </div>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Footer buttons — SVG icons, no emoji */}
        <div style={{ padding:'10px 8px 14px', borderTop:'1px solid #EEF2FA' }}>
          <button onClick={() => setAdminMode(true)}
            style={{ width:'100%', padding:'7px 10px', borderRadius:7, background:`${C.violet}08`, border:`1px solid ${C.violet}28`, color:C.violet, fontSize:11, fontWeight:600, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:6, fontFamily:'inherit' }}>
            <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
            Admin Portal
          </button>
        </div>
      </div>

      {/* ── Main area ─────────────────────────────────────────────────────── */}
      <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden', minWidth:0 }}>
        <header style={{ background:'#fff', borderBottom:`1px solid ${C.border}`, padding:'0 24px', height:54, display:'flex', alignItems:'center', gap:14, flexShrink:0 }}>
          <div style={{ fontWeight:700, fontSize:17, color:C.text, letterSpacing:-.3 }}>{TITLES[tab]}</div>
          {!baselineDone
            ? <span title="Capture the initial baseline in Model to unlock analysis." style={{ fontSize:10.5, fontWeight:700, color:'#B54708', background:'#FEF0C7', border:'1px solid #FCD9A6', padding:'2px 9px', borderRadius:20, letterSpacing:.3 }}>SETUP · BASELINE NOT CAPTURED</span>
            : <span title="Figures are illustrative and derived from the assessment state." style={{ fontSize:10.5, fontWeight:700, color:'#5B6B85', background:'#EEF2FA', border:'1px solid #DDE6F5', padding:'2px 9px', borderRadius:20, letterSpacing:.3 }}>ILLUSTRATIVE</span>}
          <div style={{ marginLeft:'auto', display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ display:'flex', alignItems:'center', gap:7, background:'#F2F5FB', border:`1px solid ${C.border}`, borderRadius:20, padding:'6px 14px', fontSize:12, color:C.muted, width:192 }}>
              <Search/><span>Search…</span>
            </div>
            <div style={{ width:1, height:20, background:C.border }}/>
            <div style={{ position:'relative', cursor:'pointer', padding:6, borderRadius:8, background:'#F2F5FB', border:`1px solid ${C.border}`, display:'flex', color:C.muted }}>
              <Bell/>
              <span style={{ position:'absolute', top:4, right:4, width:6, height:6, borderRadius:'50%', background:C.navy, border:'1.5px solid #fff' }}/>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer', padding:'5px 10px 5px 6px', borderRadius:20, border:`1px solid ${C.border}`, background:'#fff' }}>
              <div style={{ width:26, height:26, borderRadius:'50%', background:`linear-gradient(135deg,${C.navy},#3B6EC8)`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:700, color:'#fff' }}>JD</div>
              <div>
                <div style={{ fontSize:12, fontWeight:600, color:C.text, lineHeight:1 }}>J. Davies</div>
                <div style={{ fontSize:10, color:C.muted, lineHeight:1.4 }}>Lead Analyst</div>
              </div>
            </div>
          </div>
        </header>

        <main style={{ flex:1, overflowY:'auto', padding:'22px 24px' }}>
          <div style={{ maxWidth:1340, margin:'0 auto' }}>
            {locked(tab) ? (
              <div style={{ background:'#fff', border:`1px solid ${C.border}`, borderRadius:14, padding:'48px 32px', textAlign:'center', maxWidth:560, margin:'40px auto' }}>
                <div style={{ width:48, height:48, borderRadius:12, background:'#FEF0C7', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 16px' }}>
                  <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#B54708" strokeWidth="2" strokeLinecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                </div>
                <div style={{ fontSize:17, fontWeight:700, color:C.text, marginBottom:8 }}>Locked until the baseline is captured</div>
                <p style={{ fontSize:13, color:C.muted, lineHeight:1.7, marginBottom:20 }}>
                  Finish setup in <strong>Model</strong> first: collect the client's evidence, derive the zone model, then capture the initial baseline. It's fine if some evidence is missing — a gap is recorded as a finding, not a blocker. Capturing the baseline records the as-is scores and unlocks the analysis and compliance work.
                </p>
                <div style={{ display:'flex', gap:10, justifyContent:'center' }}>
                  <button onClick={()=>setTab('model')} style={{ padding:'9px 18px', borderRadius:9, background:C.navy, border:'none', color:'#fff', fontSize:13, fontWeight:600, cursor:'pointer', fontFamily:'inherit' }}>Go to Model →</button>
                </div>
              </div>
            ) : (
              <>
                {tab==='dashboard'   && <DashboardTab   onNavigate={setTab}/>}
                {tab==='model'       && <ModelTab onNavigate={setTab}/>}
                {tab==='vulns'       && <VulnerabilitiesTab onNavigate={setTab}/>}
                {tab==='risk'        && <RiskLandscapeTab onNavigate={setTab}/>}
                {tab==='assets'      && <AssetsTab/>}
                {tab==='compliance'  && <Compliance62443Tab/>}
                {tab==='mitigations' && <MitigationsTab onNavigate={setTab}/>}
                {tab==='report'      && <ReportTab onNavigate={setTab}/>}
                {tab==='logs'        && <LogsTab/>}
              </>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
