// Light theme — primary brand accent is the original dark blue (#00338D).
// Violet / sky remain the secondary accents.
export const C = {
  navy:    '#00338D',                 // primary brand accent (dark blue)
  navyDeep:'#00256A',
  sky:     '#76D2FF',
  violet:  '#510DBC',
  lavender:'#B497FF',
  critical:'#E8284B',
  high:    '#F07D00',
  low:     '#059669',
  bg:      '#F0F4FB',
  surface: '#FFFFFF',
  border:  '#DDE6F5',
  text:    '#0A1628',
  muted:   '#6B7FA3',
};
export const critColor = c =>
  c==='Critical'?C.critical : c==='High'?C.high : c==='Medium'?C.navy : C.low;
export const statusStyle = s =>
  s==='Compliant' ? {fg:'#059669',bg:'#E6F9F1'} :
  s==='Partial'   ? {fg:'#B45309',bg:'#FEF3C7'} :
                    {fg:'#DC2626',bg:'#FEE2E2'};
export const slColor = sl =>
  ['#94A3B8','#F97316','#EAB308','#22C55E','#3B82F6'][sl] ?? '#94A3B8';
export const slLabel = sl =>
  ['None','Low','Medium','High','Very High'][sl] ?? 'Unknown';
